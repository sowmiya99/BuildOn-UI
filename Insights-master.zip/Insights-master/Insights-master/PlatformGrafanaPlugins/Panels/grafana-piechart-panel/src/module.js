import _ from 'lodash';
import {PieChartCtrl} from './piechart_ctrl';

export {
  PieChartCtrl as PanelCtrl
};

