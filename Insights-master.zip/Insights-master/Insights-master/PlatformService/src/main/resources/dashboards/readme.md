Please add the default dashboards in this folder.
Elastic Search Datasource Name: #ElaticSearch_DS
Neo4j Datasource Name: #Neo4j_DS